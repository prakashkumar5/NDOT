$(document).ready(function () {
  $('.main-nav').scroller();
});